<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: user_login.php");
    exit();
}

$username = $_SESSION['username'];

$search_term = isset($_GET['search']) ? $_GET['search'] : '';

$sql = "SELECT * FROM threats WHERE (threat_name LIKE ? OR description LIKE ?) ORDER BY reported_date DESC";
$stmt = $conn->prepare($sql);
$like_search = "%$search_term%";
$stmt->bind_param("ss", $like_search, $like_search);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>All Threats - Cyber Threat Tracker</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="style.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary ctt-navbar">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">Cyber Threat Tracker</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="user_dashboard.php">Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="insert_threat.php">Add Threat</a></li>
        <li class="nav-item"><a class="nav-link active" href="view_threats.php">All Threats</a></li>
        <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>
<span class="cyber-webname">Cyber Threat Tracker</span>
<div class="cyber-welcome">Welcome, <?php echo htmlspecialchars($username); ?>! Browse all reported threats below.</div>
<div class="cyber-container">
  <h1 class="mb-4">All Threats</h1>
  <form method="GET" action="" class="row g-3 mb-4">
      <div class="col-md-8">
        <input type="text" class="form-control" name="search" placeholder="Search by name or description" value="<?php echo htmlspecialchars($search_term); ?>">
      </div>
      <div class="col-md-4">
        <button type="submit" class="btn cyber-btn w-100">Search</button>
      </div>
  </form>
  <div class="table-responsive">
    <table class="table cyber-table table-bordered">
        <thead>
            <tr>
                <th>Name</th>
                <th>Description</th>
                <th>Severity</th>
                <th>Affected Industry</th>
                <th>Date Reported</th>
                <th>Submitted By</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['threat_name']); ?></td>
                <td><?php echo htmlspecialchars($row['description']); ?></td>
                <td><?php echo htmlspecialchars($row['severity']); ?></td>
                <td><?php echo htmlspecialchars($row['affected_industry']); ?></td>
                <td><?php echo htmlspecialchars($row['reported_date']); ?></td>
                <td><?php echo htmlspecialchars($row['submitted_by']); ?></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
  </div>
  <a href="user_dashboard.php" class="btn btn-secondary mt-3">&larr; Back to Dashboard</a>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<footer class="text-center mt-5 py-3" style="background:#181f2a; color:#00ffe7; border-top:1px solid #00ffe7;">
  &copy; <?php echo date('Y'); ?> Cyber Threat Tracker &mdash; Stay Secure, Stay Ahead.
</footer>
</body>
</html>
