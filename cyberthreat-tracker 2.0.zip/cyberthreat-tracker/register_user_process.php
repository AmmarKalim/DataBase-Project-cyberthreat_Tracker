<?php
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = $_POST['full_name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $user_role = $_POST['user_role'];

    // Check for existing username/email
    $check = $conn->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
    $check->bind_param("ss", $username, $email);
    $check->execute();
    $result = $check->get_result();

    if ($result->num_rows > 0) {
        echo "Username or Email already exists.";
    } else {
        $stmt = $conn->prepare("INSERT INTO users (full_name, username, email, password, user_role) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $full_name, $username, $email, $password, $user_role);

        if ($stmt->execute()) {
            // Log registration
            $user_id = $conn->insert_id;
            $log_stmt = $conn->prepare("INSERT INTO logs (user_id, action) VALUES (?, ?)");
            $action = "Registered new user: $username";
            $log_stmt->bind_param("is", $user_id, $action);
            $log_stmt->execute();
            $log_stmt->close();
            echo "Registration successful. <a href='user_login.php'>Login now</a>";
        } else {
            echo "Registration failed.";
        }
    }
    $conn->close();
    // Registration successful
    header("Location: user_login.php?message=registered");
    exit();
}
?>


