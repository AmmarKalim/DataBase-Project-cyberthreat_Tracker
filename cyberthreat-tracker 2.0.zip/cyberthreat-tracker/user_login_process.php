<?php
session_start();
include 'db_connect.php';

$username = $_POST['username'];
$password = $_POST['password'];

$sql = "SELECT * FROM users WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
  $user = $result->fetch_assoc();

  if (password_verify($password, $user['password'])) {
    // Login success
    $_SESSION['user_id'] = $user['user_id'];
    $_SESSION['username'] = $user['username'];
    if ($user['user_role'] === 'admin') {
      $_SESSION['admin'] = $user['username'];
      header("Location: admin_dashboard.php");
      exit();
    } else {
      header("Location: user_dashboard.php");
      exit();
    }
  } else {
    // Password incorrect
    header("Location: user_login.php?error=Incorrect username or password");
    exit();
  }
} else {
  // User not found
  header("Location: user_login.php?error=User does not exist");
  exit();
}
?>
